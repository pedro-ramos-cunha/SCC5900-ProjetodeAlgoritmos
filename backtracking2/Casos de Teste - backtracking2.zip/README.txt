Arquivo zip gerado em: 19/03/2026 09:07:01 
Este arquivo contém os casos de teste cadastrados até o momento, disponibilizado pelo professor aos alunos.
Exercício: backtracking2