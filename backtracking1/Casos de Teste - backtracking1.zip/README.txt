Arquivo zip gerado em: 18/03/2026 21:51:47 
Este arquivo contém os casos de teste cadastrados até o momento, disponibilizado pelo professor aos alunos.
Exercício: backtracking1