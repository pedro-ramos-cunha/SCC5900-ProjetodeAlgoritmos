Arquivo zip gerado em: 30/04/2026 14:36:59 
Este arquivo contém os casos de teste cadastrados até o momento, disponibilizado pelo professor aos alunos.
Exercício: ProgDin5