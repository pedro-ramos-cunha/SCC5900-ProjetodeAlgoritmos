Arquivo zip gerado em: 07/03/2026 11:13:09 
Este arquivo contém os casos de teste cadastrados até o momento, disponibilizado pelo professor aos alunos.
Exercício: intro1