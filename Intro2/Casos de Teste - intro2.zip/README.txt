Arquivo zip gerado em: 07/03/2026 23:04:01 
Este arquivo contém os casos de teste cadastrados até o momento, disponibilizado pelo professor aos alunos.
Exercício: intro2