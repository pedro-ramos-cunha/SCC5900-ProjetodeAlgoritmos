Arquivo zip gerado em: 21/04/2026 19:42:31 
Este arquivo contém os casos de teste cadastrados até o momento, disponibilizado pelo professor aos alunos.
Exercício: ProgDin3