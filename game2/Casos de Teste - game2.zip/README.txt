Arquivo zip gerado em: 14/05/2026 09:34:24 
Este arquivo contém os casos de teste cadastrados até o momento, disponibilizado pelo professor aos alunos.
Exercício: game2