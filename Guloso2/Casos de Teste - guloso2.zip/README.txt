Arquivo zip gerado em: 13/03/2026 09:30:37 
Este arquivo contém os casos de teste cadastrados até o momento, disponibilizado pelo professor aos alunos.
Exercício: guloso2