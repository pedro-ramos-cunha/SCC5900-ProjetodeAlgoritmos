Arquivo zip gerado em: 11/04/2026 15:20:52 
Este arquivo contém os casos de teste cadastrados até o momento, disponibilizado pelo professor aos alunos.
Exercício: ProgDin1