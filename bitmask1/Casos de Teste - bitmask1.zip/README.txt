Arquivo zip gerado em: 07/05/2026 09:33:49 
Este arquivo contém os casos de teste cadastrados até o momento, disponibilizado pelo professor aos alunos.
Exercício: bitmask1