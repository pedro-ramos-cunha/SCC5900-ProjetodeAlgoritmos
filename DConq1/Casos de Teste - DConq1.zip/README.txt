Arquivo zip gerado em: 31/03/2026 22:12:30 
Este arquivo contém os casos de teste cadastrados até o momento, disponibilizado pelo professor aos alunos.
Exercício: DConq1