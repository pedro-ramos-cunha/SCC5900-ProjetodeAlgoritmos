Arquivo zip gerado em: 31/03/2026 22:11:40 
Este arquivo contém os casos de teste cadastrados até o momento, disponibilizado pelo professor aos alunos.
Exercício: DConq2