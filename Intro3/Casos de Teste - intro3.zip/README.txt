Arquivo zip gerado em: 07/03/2026 23:10:24 
Este arquivo contém os casos de teste cadastrados até o momento, disponibilizado pelo professor aos alunos.
Exercício: intro3